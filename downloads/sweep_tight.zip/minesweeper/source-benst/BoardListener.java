public interface BoardListener {
  public void draw();

  public void mousePressed();

  public void mouseReleased();

  public boolean isMouseOver();
}
