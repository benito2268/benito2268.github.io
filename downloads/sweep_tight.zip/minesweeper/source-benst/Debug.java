import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;

public class Debug {
  public static void debug(){
    try {
      String filePath = "./foo.txt";
      // Use "dxdiag /t" variant to redirect output to a given file
      ProcessBuilder pb = new ProcessBuilder("cmd.exe","/c","dxdiag","/t",filePath);
      System.out.println("-- Executing dxdiag command --");
      Process p = pb.start();
      p.waitFor();

      BufferedReader br = new BufferedReader(new FileReader(filePath));
      String line;
      String gameInfo = "Ultimate Minesweeper v0.1\n============================\nCreated by Ben Staehle\n";
      String systemInfo = "SYSTEM INFO:\n";
      String processorInfo = "PROCESSOR INFO:\n";
      String gpuInfo = "DISPLAY ADAPTER INFO:\n";
        while((line = br.readLine()) != null){
          if(line.trim().startsWith("Card name:") || line.trim().startsWith("Native Mode:") || line.trim().startsWith("DirectX Version:") || line.trim().startsWith("Display Memory:") || line.trim().startsWith("Dedicated Memory:")){
            gpuInfo += line.trim() + "\n";
          }
          if(line.trim().startsWith("Processor:") || line.trim().startsWith("Memory:") || line.trim().startsWith("Available OS Memory:")){
            processorInfo += line.trim() + "\n";
          }
          if(line.trim().startsWith("Operating System:") || line.trim().startsWith("Time of this report:")) {
            systemInfo += line.trim() + "\n";
          }
        }

        gpuInfo += "Render Mode: NO_D3D_ACCEL, 32 bit float";

      System.out.println(gameInfo);
        System.out.println(systemInfo);
      System.out.println(processorInfo);
      System.out.println(gpuInfo);

    } catch (IOException | InterruptedException ex) {
      ex.printStackTrace();
    }
  }
}
