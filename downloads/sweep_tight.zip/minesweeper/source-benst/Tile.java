import processing.core.PImage;

import java.io.File;

public class Tile implements BoardListener{
  protected static GameBoard board; //the current gameboard
  protected int boardPosRow;
  protected int boardPosCol;
  protected boolean losingMine;
  protected boolean flagged;
  protected int isFlagCorrect; // -1 if incorrect, 0 if not flagged, 1 if correct
  protected int newlyRevealedZero = 0; // 0 if no, 1 if yes
  private PImage texture;
  private int value; //the number of mines in radius of this tile, -1 if mine
  private float x;
  private float y;
  private boolean revealed = false;


  public Tile(float x, float y, int ArrRow, int ArrCol, String imageFileName) {
    this.losingMine = false;
    this.flagged = false;
    this.isFlagCorrect = 0;
    this.x = x;
    this.y = y;
    this.boardPosCol = ArrCol;
    this.boardPosRow = ArrRow;
    this.texture = board.loadImage(imageFileName);
  }

  public static void setBoard(GameBoard toSet) {
    board = toSet;
  }

  public float getX(){
    return this.x;
  }

  public float getY(){
    return this.y;
  }

  @Override
  public void draw(){
    board.image(this.texture, this.x, this.y);
  }

  @Override
  public void mousePressed(){
    if(board.mouseButton == board.LEFT && !this.flagged) {
      this.reveal();
    } else if(board.mouseButton == board.RIGHT) {
      if(this.flagged == false) {
        this.flag();
      } else {
        this.unflag();
      }
    }
  }

  @Override
  public void mouseReleased(){

  }

  @Override
  public boolean isMouseOver(){
    final int TILE_WIDTH = 30;
    final int TILE_HEIGHT = 30;

    return board.mouseX >= this.getX() - TILE_WIDTH / 2
        && board.mouseX <= this.getX() + TILE_WIDTH / 2
        && board.mouseY >= this.getY() - TILE_HEIGHT / 2
        && board.mouseY <= this.getY() + TILE_HEIGHT / 2;
  }

  public void reveal(){
    if(this.getValue() == -1) {
      this.setTexture(board.loadImage("resources" + File.separator + "minelose.png"));
      this.losingMine = true;
      board.loseGame();
    } else if(this.getValue() == 0) {
      this.setTexture(board.loadImage("resources" + File.separator + "tile.png"));
      GameBoard.zeroReveal(this, this.board.objects);
      GameBoard.checkZeroReveal(this.board.objects);
    } else if(this.getValue() == 1) {
      this.setTexture(board.loadImage("resources" + File.separator + "one.png"));
    } else if(this.getValue() == 2) {
      this.setTexture(board.loadImage("resources" + File.separator + "two.png"));
    } else if(this.getValue() == 3) {
      this.setTexture(board.loadImage("resources" + File.separator + "three.png"));
    } else if(this.getValue() == 4){
      this.setTexture(board.loadImage("resources" + File.separator + "four.png"));
    } else if(this.getValue() == 5){
      this.setTexture(board.loadImage("resources" + File.separator + "five.png"));
    } else if(this.getValue() == 6) {
      this.setTexture(board.loadImage("resources" + File.separator + "six.png"));
    } else if(this.getValue() == 7) {
      this.setTexture(board.loadImage("resources" + File.separator + "seven.png"));
    } else if(this.getValue() == 8) {
      this.setTexture(board.loadImage("resources" + File.separator + "eight.png"));
    }
    this.revealed = true;
  }

  public void zeroSwap(){
    this.setTexture(board.loadImage("resources" + File.separator + "tile.png"));
    this.revealed = true;
  }

  public void valueSwap(){
    if(this.getValue() == 1) {
      this.setTexture(board.loadImage("resources" + File.separator + "one.png"));
    } else if(this.getValue() == 2) {
      this.setTexture(board.loadImage("resources" + File.separator + "two.png"));
    } else if(this.getValue() == 3) {
      this.setTexture(board.loadImage("resources" + File.separator + "three.png"));
    } else if(this.getValue() == 4){
      this.setTexture(board.loadImage("resources" + File.separator + "four.png"));
    } else if(this.getValue() == 5){
      this.setTexture(board.loadImage("resources" + File.separator + "five.png"));
    } else if(this.getValue() == 6) {
      this.setTexture(board.loadImage("resources" + File.separator + "six.png"));
    } else if(this.getValue() == 7) {
      this.setTexture(board.loadImage("resources" + File.separator + "seven.png"));
    } else if(this.getValue() == 8) {
      this.setTexture(board.loadImage("resources" + File.separator + "eight.png"));
    }
    this.revealed = true;
  }

  public void showMines() {
    this.setTexture(board.loadImage("resources" + File.separator + "mine.png"));
    this.revealed = true;
  }

  public void flag(){
    if(this.getRevealed() == false) {
      this.flagged = true;
      if(this.value == -1) {
        this.isFlagCorrect = 1;
      } else {
        this.isFlagCorrect = -1;
      }
      this.setTexture(board.loadImage("resources" + File.separator + "flag.png"));
    }
  }

  public void unflag(){
    this.flagged = false;
    this.isFlagCorrect = 0;
    this.setTexture(board.loadImage("resources" + File.separator + "tilecovered.png"));
  }

  public boolean getRevealed() {
    return this.revealed;
  }

  public int getValue(){
    return this.value;
  }

  public void setValue(int value) {
    this.value = value;
  }

  public PImage getTexture(){
    return this.texture;
  }

  public void setTexture(PImage texture) {
    this.texture = texture;
  }

}
