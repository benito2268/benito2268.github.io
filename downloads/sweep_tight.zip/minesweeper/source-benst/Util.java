import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Util {

  public static Tile hasNeighbor(Direction d, Tile[][] board, Tile tile) {
    if (board == null) {
      throw new IllegalStateException("Unexpected Generation Error, Aborting!");
    }
    if(d == Direction.N) {
      try{
        Tile t = board[tile.boardPosRow - 1][tile.boardPosCol];
        return t;
      } catch(Exception e) {
        return null;
      }
    } else if(d == Direction.NE) {
      try{
        Tile t = board[tile.boardPosRow - 1][tile.boardPosCol + 1];
        return t;
      } catch(Exception e) {
        return null;
      }
    } else if(d == Direction.E) {
      try{
        Tile t = board[tile.boardPosRow][tile.boardPosCol + 1];
        return t;
      } catch(Exception e) {
        return null;
      }
    } else if(d == Direction.SE) {
      try{
        Tile t = board[tile.boardPosRow + 1][tile.boardPosCol + 1];
        return t;
      } catch(Exception e) {
        return null;
      }
    } else if(d == Direction.S) {
      try{
        Tile t = board[tile.boardPosRow + 1][tile.boardPosCol];
        return t;
      } catch(Exception e) {
        return null;
      }
    } else if(d == Direction.SW) {
      try{
        Tile t = board[tile.boardPosRow + 1][tile.boardPosCol - 1];
        return t;
      } catch(Exception e) {
        return null;
      }
    } else if(d == Direction.W) {
      try{
        Tile t = board[tile.boardPosRow][tile.boardPosCol - 1];
        return t;
      } catch(Exception e) {
        return null;
      }
    } else if(d == Direction.NW) {
      try{
        Tile t = board[tile.boardPosRow - 1][tile.boardPosCol - 1];
        return t;
      } catch(Exception e) {
        return null;
      }
    }
    return null;
  }

  public static Tile hasCardinalNeighbor(CardinalDirection d, Tile[][] board, Tile tile) {
    if (board == null) {
      throw new IllegalStateException("Unexpected Generation Error, Aborting!");
    }
    if(d == CardinalDirection.N) {
      try{
        Tile t = board[tile.boardPosRow - 1][tile.boardPosCol];
        return t;
      } catch(Exception e) {
        return null;
      }
    } else if(d == CardinalDirection.E) {
      try{
        Tile t = board[tile.boardPosRow][tile.boardPosCol + 1];
        return t;
      } catch(Exception e) {
        return null;
      }
    } else if(d == CardinalDirection.S) {
      try{
        Tile t = board[tile.boardPosRow + 1][tile.boardPosCol];
        return t;
      } catch(Exception e) {
        return null;
      }
    } else if(d == CardinalDirection.W) {
      try{
        Tile t = board[tile.boardPosRow][tile.boardPosCol - 1];
        return t;
      } catch(Exception e) {
        return null;
      }
    }
    return null;
  }

  public static boolean inBounds(Tile t, Tile[][] collection) {
    return t.boardPosCol >= 0
         &&t.boardPosCol < collection[t.boardPosRow].length
         &&t.boardPosRow >= 0
         &&t.boardPosRow < collection.length;
  }

  public static int[] readFile() throws IOException {
    int[] args = new int[3];
    File file = new File("config.txt");
    Scanner inFile = new Scanner(file);
    while (inFile.hasNextLine()){
      String str = inFile.nextLine();
      if(str.contains("numberOfColumns=")) {
        args[0] = Integer.parseInt(str.substring(16));
      }
      if(str.contains("numberOfRows=")) {
        args[1] = Integer.parseInt(str.substring(13));
      }
      if(str.contains("percent=")) {
        float f = Float.parseFloat(str.substring(8));
        int i = (int)(f * 100);
        args[2] = i;
      }
    }
    inFile.close();
    return args;
  }

}
