public enum CardinalDirection {
  N, E, S, W
}
