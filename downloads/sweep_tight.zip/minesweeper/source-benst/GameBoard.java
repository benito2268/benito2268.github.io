
import processing.core.PApplet;

import java.io.File;
import java.util.Random;

public class GameBoard extends PApplet{
  protected Tile[][] objects;
  protected Random rand;
  private boolean gameWon = false;
  private static boolean shouldExit = false;
  private int NUMROWS;
  private int NUMCOLS;
  private int SCREEN_WIDTH;
  private int SCREEN_HEIGHT;
  private int PERCENT;

  @Override
  public void settings(){
    try{
      this.NUMCOLS = Util.readFile()[0];
      this.NUMROWS = Util.readFile()[1];
      this.PERCENT = Util.readFile()[2];
    } catch(Exception e) {
      System.out.println("unexpected file io error: " + e.getMessage());
    }
    SCREEN_WIDTH = NUMCOLS*30;
    SCREEN_HEIGHT = NUMROWS*30;

    size(SCREEN_WIDTH, SCREEN_HEIGHT);
  }

  @Override
  public void setup(){
    //set window and graphics settings
    // Set and display the title of the display window
    this.getSurface().setTitle("Minesweeper *TEST_BUILD*");
    // Set the location from which images are drawn to CENTER
    this.imageMode(PApplet.CENTER);
    // Set the location from which rectangles are drawn.
    this.rectMode(PApplet.CORNERS);
    // rectMode(CORNERS) interprets the first two parameters of rect() method
    // as the location of one corner, and the third and fourth parameters as
    // the location of the opposite corner.
    // rect() method draws a rectangle to the display window
    Tile.setBoard(this);
    this.focused = true;
    this.textAlign(PApplet.CENTER, PApplet.CENTER);
    this.objects = new Tile[NUMROWS][NUMCOLS];
    this.rand = new Random();
    populate();
    genBoard();
    calcSquares();
    //rows are stored in the ArrayList from left to right, and top to bottom
    //each row is equal length and the end of a row can be determined using NUMCOLS
  }

  public void populate(){
    int xPos;
    int yPos = 15;
    for(int row = 0; row < this.objects.length; row++){
      xPos = 15;
      for(int col = 0; col < this.objects[row].length; col++){
        this.objects[row][col] = new Tile(xPos, yPos, row, col, "resources" + File.separator + "tilecovered.png");
        xPos += 30;
      }
      yPos += 30;
    }
  }

  public static void zeroReveal(Tile t, Tile[][] objects) {
      if (t.getRevealed() != true && t.getValue() == 0) {
        t.newlyRevealedZero = 1;
        t.zeroSwap();
        if(t.boardPosRow + 1 < objects.length) {
          zeroReveal(objects[t.boardPosRow + 1][t.boardPosCol], objects);
        }
        if(t.boardPosRow - 1 >= 0) {
          zeroReveal(objects[t.boardPosRow - 1][t.boardPosCol], objects);
        }
        if(t.boardPosCol + 1 < objects[t.boardPosRow].length) {
          zeroReveal(objects[t.boardPosRow][t.boardPosCol + 1], objects);
        }
        if(t.boardPosCol - 1 >= 0) {
          zeroReveal(objects[t.boardPosRow][t.boardPosCol - 1], objects);
        }
        System.out.println(t.getValue());
      } else {
        if(t.getValue() != 0) {
          t.reveal();
        }
        return;
      }
  }

  public static void revealAllSurrounding(Tile t, Tile[][] objects) {
    if(t.getValue() == 0) {
      if((t.boardPosRow - 1 ) >= 0) {
        objects[t.boardPosRow - 1][t.boardPosCol].valueSwap();
      }
      if((t.boardPosRow - 1) >= 0 && (t.boardPosCol + 1) < objects[t.boardPosRow].length) {
        objects[t.boardPosRow - 1][t.boardPosCol + 1].valueSwap();
      }
      if((t.boardPosCol + 1) > objects[t.boardPosRow].length){
        objects[t.boardPosRow][t.boardPosCol + 1].valueSwap();
      }
      if((t.boardPosRow + 1) > objects.length && (t.boardPosCol + 1) < objects[t.boardPosRow].length) {
        objects[t.boardPosRow + 1][t.boardPosCol + 1].valueSwap();
      }
      if((t.boardPosRow + 1) < objects.length) {
        objects[t.boardPosRow + 1][t.boardPosCol].valueSwap();
      }
      if((t.boardPosRow + 1) < objects.length && (t.boardPosCol - 1) >= 0) {
        objects[t.boardPosRow + 1][t.boardPosCol - 1].valueSwap();
      }
      if(!(t.boardPosCol - 1 < 0)) {
        objects[t.boardPosRow][t.boardPosCol - 1].valueSwap();
      }
      if(!(t.boardPosRow - 1 < 0) && !(t.boardPosCol - 1 < 0)) {
        objects[t.boardPosRow - 1][t.boardPosCol - 1].valueSwap();
      }
    } else {
      //only 0 tiles have this feature
      return;
    }
  }

  public static void checkZeroReveal(Tile[][] objects){
    for(int row = 0; row < objects.length; row++){
      for(int col = 0; col < objects[row].length; col++){
        if(objects[row][col].newlyRevealedZero == 1){
          revealAllSurrounding(objects[row][col], objects);
          objects[row][col].newlyRevealedZero = 0;
        }
      }
    }
  }


  public void genBoard(){
    for(int row = 0; row < this.objects.length; row++){
      for(int col = 0; col < this.objects[row].length; col++){
        int low = 0; //inclusive
        int high = 10000; //exclusive
        int percentChance = this.PERCENT;
        if((rand.nextInt(high - low) + low) < percentChance)  {
          objects[row][col].setValue(-1);
        }
      }
    }
  }

  public void calcSquares(){
    for(int row = 0; row < this.objects.length; row++){
      for(int col = 0; col < this.objects[row].length; col++){
        int thisVal = 0;
        for(Direction d : Direction.values()) {
          if(Util.hasNeighbor(d, objects, objects[row][col]) != null) {
            if(Util.hasNeighbor(d, objects, objects[row][col]).getValue() == -1) {
              thisVal++;
            }
          }
        }
        if(objects[row][col].getValue() != -1) {
          objects[row][col].setValue(thisVal);
        }
      }
    }
  }

  @Override
  public void draw(){
    checkWin();
    if(this.gameWon) {
      winGame();
    }
    for(int row = 0; row < this.objects.length; row++){
      for(int col = 0; col < this.objects[row].length; col++){
        this.objects[row][col].draw();
      }
    }
  }

  @Override
  public void mousePressed(){
    if(shouldExit) return;
    for(int row = 0; row < this.objects.length; row++){
      for(int col = 0; col < this.objects[row].length; col++){
        if(objects[row][col].isMouseOver()) {
          this.objects[row][col].mousePressed();
          return;
        }
      }
    }
  }

  @Override
  public void mouseReleased(){
    for(int row = 0; row < this.objects.length; row++){
      for(int col = 0; col < this.objects[row].length; col++){
        this.objects[row][col].mouseReleased();
      }
    }
  }

  @Override
  public void keyPressed(){
    if(Character.toUpperCase(this.key) == 'C') {
//      if(shouldExit) return;
//      this.clear();
    } else if(Character.toUpperCase(this.key) == 'X') {
      System.exit(0);
    } else if(Character.toUpperCase(this.key) == 'R') {
      //reset routine
      shouldExit = false;
      this.objects = new Tile[NUMROWS][NUMCOLS];
      this.rand = new Random();
      populate();
      genBoard();
      calcSquares();
    }
  }

  public void loseGame(){
    shouldExit = true;
    for(int row = 0; row < this.objects.length; row++){
      for(int col = 0; col < this.objects[row].length; col++){
        if(objects[row][col].getValue() == -1 && objects[row][col].losingMine == false) {
          objects[row][col].showMines();
        }
      }
    }
  }

  public int countMines(){
    int numMines = 0;
    for(int row = 0; row < this.objects.length; row++){
      for(int col = 0; col < this.objects[row].length; col++) {
        if(objects[row][col].getValue() == -1) {
          numMines++;
        }
      }
    }
    return numMines;
  }


  public void checkWin(){
    int numUncovered = 0;
    for(int row = 0; row < this.objects.length; row++){
      for(int col = 0; col < this.objects[row].length; col++) {
        if(objects[row][col].getRevealed() == false) {
          numUncovered++;
        }
      }
    }
    if(numUncovered == countMines()){
      this.gameWon = true;
    }
  }

  public void winGame(){
    shouldExit = true;
    clear();
  }

  public void clear(){
    for(int row = 0; row < this.objects.length; row++){
      for(int col = 0; col < this.objects[row].length; col++){
        if(objects[row][col].flagged == false || objects[row][col].isFlagCorrect == -1){
          if(objects[row][col].getValue() == -1) {
            objects[row][col].flag();
          } else {
            this.objects[row][col].reveal();
          }
        }
      }
    }
  }

  public static void main(String[] args) {
    //Debug.debug();
    PApplet.main("GameBoard");
  }
}
